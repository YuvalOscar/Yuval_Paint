package com.example.paint;

import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.view.MotionEvent;

public class PathShape extends Shape {

    private int xEnd;
    private int yEnd;
    private Path path;
    private MotionEvent event;

    public PathShape(int x, int y, String color,int width,boolean fill,MotionEvent event) {
        super(x, y, color,width,fill);
        xEnd = x;
        yEnd = y;
        path = new Path();
        this.event = event;
        path.moveTo(x, y);
    }

    @Override
    public void updatePoint(int xe, int ye) {
        xEnd = xe;
        yEnd = ye;

        if (MotionEvent.ACTION_DOWN == event.getAction()) {
            path.moveTo(x, y);
        }
    }

    @Override
    public void draw(Canvas canvas, Paint paint) {
        super.draw(canvas,paint);
        fill = false;
        if(fill == true)
            paint.setStyle(Paint.Style.FILL);
        if (MotionEvent.ACTION_MOVE== event.getAction()) {
            path.lineTo(xEnd, yEnd);
        }
        canvas.drawPath(path,paint);
    }
}