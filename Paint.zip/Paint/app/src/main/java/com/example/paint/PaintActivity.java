package com.example.paint;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import android.graphics.Color;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.Toast;

import java.util.UUID;

import yuku.ambilwarna.AmbilWarnaDialog;


public class PaintActivity extends AppCompatActivity{
    private static final String TAG = "PaintActivity";
    private FrameLayout frame;
    private PaintView paintView;
    private Button undo, save;
    private int mDefaultColor;
    private int countSaved=1;
    private Button Colorpal;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_paint);
        frame = findViewById(R.id.frm);
        paintView = new PaintView(this);
        frame.addView(paintView);
        undo=(Button) findViewById(R.id.btnPoint);
        save = (Button) findViewById(R.id.btnSave);
        mDefaultColor= ContextCompat.getColor(PaintActivity.this,R.color.design_default_color_primary);
        Colorpal=(Button)findViewById(R.id.colorPal);
        Colorpal.setOnClickListener(new View.OnClickListener() {
                        @Override
            public void onClick(View v) {
                openColorPicker();
            }
        });
    }
    public void openColorPicker(){
        AmbilWarnaDialog colorPicker=new AmbilWarnaDialog(this, mDefaultColor, new AmbilWarnaDialog.OnAmbilWarnaListener() {
            @Override
            public void onCancel(AmbilWarnaDialog dialog) {

            }

            @Override
            public void onOk(AmbilWarnaDialog dialog, int color) {
                mDefaultColor=color;
                String hexColor = String.format("#%06X", (0xFFFFFF & mDefaultColor));
                paintView.setColor(hexColor);
            }
        });
        colorPicker.show();
    }
    public boolean onCreateOptionsMenu(Menu menu)
    {
        getMenuInflater().inflate(R.menu.nev_menu, menu);
        return true;
    }

    public boolean onOptionsItemSelected(MenuItem item)
    {
        super.onOptionsItemSelected(item);
        int id=item.getItemId();
        if(id==R.id.action_widthPlus){
            paintView.WidthPlus();
            Toast.makeText(this,"width: "+paintView.GetWidth(),Toast.LENGTH_SHORT).show();
        }
        if(id==R.id.action_widthMin){
            paintView.WidthMin();
            Toast.makeText(this,"width: "+paintView.GetWidth(),Toast.LENGTH_SHORT).show();
        }
        if(id==R.id.action_fill){
            paintView.SetFill();
            Toast.makeText(this,"fill: "+paintView.GetFill(),Toast.LENGTH_SHORT).show();
        }
        if (id == R.id.showMaxClose){
            paintView.DelBig();
            Toast.makeText(this,"",Toast.LENGTH_SHORT).show();
        }
        return true;
    }

    public void addLine(View view) {
        paintView.addLine();
    }
    public void addRect(View view) {
        paintView.addRect();
    }
    public void addPath(View view) {
        paintView.addPath();
    }
    public void addCircle(View view) {
        paintView.addCircle();
    }

    public void changeColor(View view)
    {
        String color = view.getTag().toString();
        paintView.setColor(color);
    }


    public void clear(View view) {
        undo.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View view) {
                paintView.undoPath();
                return false;
            }
        });
        undo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                paintView.undo();
            }
        });
        save.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {
                if (view.getId() == R.id.btnSave) {
                    paintView.setDrawingCacheEnabled(true);
                    String imgSaved = MediaStore.Images.Media.insertImage(
                            getContentResolver(), paintView.getDrawingCache(), UUID.randomUUID().toString() + ".png", "drawing");
                    if (imgSaved != null) {
                        Toast.makeText(getApplicationContext(), "Saved", Toast.LENGTH_LONG).show();
                    } else {
                        Toast.makeText(getApplicationContext(), "Error - Image not saved", Toast.LENGTH_LONG).show();
                    }
                    paintView.destroyDrawingCache();
                }
            }
        });
    }
}